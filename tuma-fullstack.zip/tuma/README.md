# tuma. — parcel pre-booking prototype

A fullstack Next.js 14 demo of "book online, print a ticket, skip the counter queue"
for Kenyan bus/courier parcel desks (Easycoach, Modern Coast, Guardian Angel).

## What's real vs simulated

**Real:**
- Full booking flow (parcel → route → carrier → pay → ticket) with server-side state
- API routes that create/fetch/update bookings (`app/api/...`)
- QR code generated server-side per booking (`qrcode` package)
- A `/verify/[ref]` page simulating what counter staff see when they scan the code

**Simulated (by design, for a demo):**
- Payment: `/api/mpesa/stk` fakes a ~1.5s delay and marks the booking "paid" —
  it does not call Safaricom's Daraja API. Swap in a real STK Push call here
  when you're ready to test with real money.
- Storage: bookings live in an in-memory `Map` (`lib/store.ts`), not a database.
  Data resets whenever the server restarts. Swap in Postgres/Supabase/etc. for
  anything beyond a demo.

## Run it locally

```bash
npm install
npm run dev
```

Then open:
- `http://localhost:3000` — landing page
- `http://localhost:3000/book` — the booking wizard
- After paying, you're redirected to `/ticket/[ref]` — the printable ticket + QR
- The ticket page links to `/verify/[ref]` — the "counter staff" scan simulation

## Project structure

```
app/
  page.tsx                 landing page
  book/page.tsx             booking wizard (client component)
  ticket/[ref]/page.tsx      generated ticket + QR (server component)
  verify/[ref]/page.tsx      counter-staff verification view
  api/bookings/route.ts       POST create a booking
  api/bookings/[ref]/route.ts GET one booking, PATCH to verify
  api/mpesa/stk/route.ts      simulated M-Pesa STK push
lib/
  types.ts    Booking type, carrier list, destinations
  store.ts     in-memory booking store
components/
  DepartureBoard.tsx  hero animation
  Ticket.tsx           shared ticket visual
  PrintButton.tsx      client-side window.print() trigger
```

## Next steps toward a real pilot

1. Replace `lib/store.ts` with a real database (Postgres via Supabase/Neon is
   fastest to stand up).
2. Replace `/api/mpesa/stk` with a real Safaricom Daraja STK Push call, plus a
   callback route to receive Safaricom's payment confirmation.
3. Add an admin view per carrier so their staff can see all bookings routed to
   them, not just look up one ref at a time.
4. Deploy (Vercel is the path of least resistance for Next.js) so the QR code
   can encode a real scannable URL for a live demo.
