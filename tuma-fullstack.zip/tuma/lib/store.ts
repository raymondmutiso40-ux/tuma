import { Booking } from "./types";

// Demo-only in-memory store. In a real system this would be a database
// (e.g. Postgres) shared across serverless instances. Using globalThis
// keeps data alive across Next.js dev-server hot reloads.

declare global {
  // eslint-disable-next-line no-var
  var __tumaBookings: Map<string, Booking> | undefined;
}

function getStore(): Map<string, Booking> {
  if (!global.__tumaBookings) {
    global.__tumaBookings = new Map();
  }
  return global.__tumaBookings;
}

export function createBooking(booking: Booking) {
  getStore().set(booking.ref, booking);
  return booking;
}

export function getBooking(ref: string): Booking | undefined {
  return getStore().get(ref);
}

export function updateBooking(ref: string, patch: Partial<Booking>): Booking | undefined {
  const store = getStore();
  const existing = store.get(ref);
  if (!existing) return undefined;
  const updated = { ...existing, ...patch };
  store.set(ref, updated);
  return updated;
}

export function generateRef(): string {
  const num = Math.floor(100000 + Math.random() * 900000);
  return `TM-${num}`;
}
